<?php return array (
  0 => 
  array (
    0 => 'id',
    1 => 'name',
    2 => 'age',
  ),
  1 => 
  array (
    0 => 'id',
  ),
  2 => 
  array (
    0 => 'name',
    1 => 'age',
  ),
  3 => 
  array (
    0 => 'id',
    1 => 'name',
    2 => 'age',
  ),
  4 => 
  array (
    'id' => 0,
    'name' => 2,
    'age' => 0,
  ),
  5 => 
  array (
    'id' => true,
    'age' => true,
  ),
  8 => 'id',
  9 => 
  array (
    'id' => 1,
    'name' => 2,
    'age' => 1,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'name' => '',
  ),
  13 => 
  array (
  ),
); 