<?php
return [
   /* 'user' => [
        'className' => 'Admin\Modules\User\Module',
        'path' => PROJECT_PATH . '/modules/user/Module.php',
        'namespace'=>'Admin\Modules\User\Controllers'
    ]*/
   /**
    * 'order'=>function($di){
        $di->set('a','a');
    *   $di->get('loder')->registerNamespace([]);
    * }
    */

];