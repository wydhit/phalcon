<?php


return [
   /* [
        'pattern' => '',
        'paths' => '',
        'httpMethods' => '',
        'position' => '',
    ],*/

];