<?php

/*本项目主要配置文件 会对公共配置文件重新*/
return new Phalcon\Config([]);


