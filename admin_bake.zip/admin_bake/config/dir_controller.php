<?php
/*控制器分层配置*/
return[
//    'finance',
//    'user',
//    'access'
];