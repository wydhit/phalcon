<?php
/**
 * Created by PhpStorm.
 * User: wyd
 * Date: 2017-07-04
 * Time: 12:29
 */

namespace Admin\Modules\User\Models;


class Test
{
    function __construct($value=null)
    {
        $this->value=$value;
    }

}