<?php
/**
 * Created by PhpStorm.
 * User: wyd
 * Date: 2017-07-28
 * Time: 17:29
 */

namespace Admin\Controllers;


use Common\Controllers\BaseController;
use Common\Services\UserService;
use Phalcon\Http\Request;

class LoginController extends BaseController
{
    public function loginAction(Request $request)
    {
        if($this->request->isPost()){
            $u_name=$request->get('name');
            $u_pass=$request->get('pass');
            if(UserService::instance()->LoginByName($u_name,$u_pass,'admin','sys')){
                return $this->sendSuccessJson('登陆成功');
            }else{
                return $this->sendErrorJson('登录失败');
            }
        }else{
            return $this->render();
        }
    }
}