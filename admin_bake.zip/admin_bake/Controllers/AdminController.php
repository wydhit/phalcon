<?php

namespace Admin\Controllers;

use Common\Controllers\BaseController;
use Common\Services\CommonService;
use Common\Services\UserService;

class AdminController extends BaseController
{
    /*admin项目相关业务*/
    public $adminInfo = [];
    public $adminId = 0;
    /**
     * 用户相关业务
     * @var $sessionService  UserService;
     */
    public $userService;
    /**
     * 通用业务
     * @var $commonRepository  CommonService;
     */
    public $commonService;

    public function initialize()
    {
        $this->userService = UserService::instance();
        $this->commonService = UserService::instance();
        $this->action = $this->dispatcher->getActionName();
        $this->controller = $this->dispatcher->getControllerName();
        $this->adminInfo = $this->userRepository->getAdminInfo();
        $this->adminId = isset($this->adminInfo['id']) ? $this->adminInfo['id'] : 0;
        $this->checkAdminLogin();
        $this->addTitle('E家神灯管理中心');
    }

    public function beforeExecuteRoute()
    {
    }

    /**
     * 检查登录
     */
    protected function checkAdminLogin()
    {

        if (empty($this->adminInfo) || empty($this->adminId)) {//没有登录去登陆
            $goUrl = $this->url->get('login/login');
            $this->commonRepository->setLoginFromUrl($goUrl);
            throw new \Common\Exception\UserNotLoginException('需要登录', [], [], $goUrl);
        }

    }


    public function notFoundAction()
    {
        return parent::notFoundAction();

    }
}